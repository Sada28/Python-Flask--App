from flask import Flask, render_template, request
from pymongo import MongoClient
from werkzeug.utils import secure_filename
import os

app = Flask("myapp")

client = MongoClient('mongodb://127.0.0.1:27017/')
mydb = client["train_db1"]
mycol =client["trains"]
mycol=client["bookings"]
 
@app.route("/")
def login2():
  return render_template("Login.html")

@app.route("/Login")   
def login():
  return render_template("Login.html")

@app.route("/logout")
def logout():
  return main()


@app.route("/register",methods =['POST', 'GET'])
def auth():
       return render_template("Register.html")

@app.route("/submit", methods=['POST'])
def show_data():
    if request.method == 'POST':
        name = request.form.get("a")
        user = request.form.get("b")
        email = request.form.get("c")
        gender = request.form.get("d")
        passw = request.form.get("e")
        values=[{
                    "a"	:name,
                    "b" :user,
                    "c":email,
                    "d" :gender,
                    "e" :passw

                }]
        client['train_db1']['trains'].insert_many(values)
        return render_template("Regdata.html" , a=name)

@app.route("/result",methods =['GET'])
def result():
    if request.method == "GET":
        user=request.form.get("b")
        passw=request.form.get("e")
    result = client['train_db1']['trains'].find({"b" : user , "e" : passw} )
    user=[]
    passw=[]
    for i in result:
      user=i['b']
      passw=i['e']
    if user== user and passw==passw:  
      return render_template("Home.html")
    else:
      error="Check the username and passwoord again!!"
      return render_template("Login.html" , error = error)

# Second Data BASE
@app.route("/Home",methods =['POST', 'GET'])
def authh():
       return render_template("Home.html")

@app.route("/booking", methods=['POST'])
def book():
    if request.method == 'POST':
        jf = request.form.get("a")
        jt = request.form.get("b")
        jd = request.form.get("c")
        cls = request.form.get("d")
        passen=request.form.get("e")
        prc=request.form.get("f")
        values=[{
                    "a"	:jf,
                    "b" :jt,
                    "c" :jd,
                    "d" :cls,
                    "e" :passen,
                    "f" :prc
                     }]
        client['train_db1']['bookings'].insert_many(values)  
      
        return render_template("Homedata.html")
@app.route("/ticket")
def ticket():
  if request.method == "GET":
        jf=request.args.get("a")
        jt=request.args.get("b")
        jd=request.args.get("c")
        cls=request.args.get("d")
        passen=request.args.get("e")
        prc=request.args.get("f")
        result =client['train_db']['bookings'].find({"a":jf,"b":jt,"c":jd,"d":cls,"e":passen,"f":prc} )
        if result.count() == 0:
           return render_template("Booking.html")

        for i in result:
            jff=(i["a"])
            jtt=(i["b"])
            jdd=(i["c"])
            clss=(i["d"])
            passenn=(i["e"])
            prc=(i["f"])
              
            

            formrender=render_template(
                "Booking.html", froms=jff, to=jtt,dates=jdd,classs=clss,pasenn=passenn,rate=prc)    
           
            return formrender

if __name__ =='__main__':
    app.run(debug=True)